/*H**************************************************************************
* $RCSfile: can_bdr.h,v $
*----------------------------------------------------------------------------
* Copyright (c) 2003 Atmel.
*----------------------------------------------------------------------------
* RELEASE:      $Name:  $      
* REVISION:     $Revision: 1.1 $     
* FILE_CVSID:   $Id: can_bdr.h,v 1.1 2005/12/21 11:29:17 akhe Exp $       
*----------------------------------------------------------------------------
* PURPOSE: 
* This file provides a set of pre-define configuration FOSC/CAN_BAURATE.
* 
*****************************************************************************/

#ifndef _CAN_BDR_H_
#define _CAN_BDR_H_

#ifndef FOSC
#error You must define FOSC in config.h

#elif FOSC == 8000
  #if CAN_BAUDRATE == 100
    #define CONF_CANBT1  0x06
    #define CONF_CANBT2  0x0C
    #define CONF_CANBT3  0x5A
  #elif

    #error the values for this baudrate is not in the file
  #endif

#else
  #error no values are entered for this frequency
  
#endif

#endif /* _CAN_BDR_H_ */
