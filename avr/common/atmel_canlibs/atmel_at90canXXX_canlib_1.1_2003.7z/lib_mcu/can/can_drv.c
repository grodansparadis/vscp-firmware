/*C**************************************************************************
* $RCSfile: can_drv.c,v $
*----------------------------------------------------------------------------
* Copyright (c) 2003 Atmel.
*----------------------------------------------------------------------------
* RELEASE:      $Name:  $      
* REVISION:     $Revision: 1.1 $     
* FILE_CVSID:   $Id: can_drv.c,v 1.1 2005/12/21 11:29:17 akhe Exp $       
*----------------------------------------------------------------------------
* PURPOSE: 
* provide low level functions to CAN controller   
*
******************************************************************************/

/*_____ I N C L U D E - F I L E S ____________________________________________*/

#include "config.h"
#include "can_drv.h"


/*_____ G L O B A L S ________________________________________________________*/




/*_____ P R I V A T E - F U N C T I O N S - D E C L A R A T I O N ____________*/


/*_____ L O C A L S __________________________________________________________*/


/*_____ P U B L I C - F U N C T I O N S ______________________________________*/


/*_____ P R I V A T E - F U N C T I O N S ____________________________________*/


/*F****************************************************************************
* FUNCTION_NAME: Can_clear_all_MOB                                                  
*----------------------------------------------------------------------------
* PARAMS:   none
* return:   none
*----------------------------------------------------------------------------
* PURPOSE: This function clears the Mailbox content.
* controller
*****************************************************************************/
void Can_clear_all_MOB (void)
{
  Uchar num_mob, num_data;

  for (num_mob = 0; num_mob < NB_MOB; num_mob++)
  {
    CANPAGE  = (num_mob << 4);
    CANSTMOB = 0;
    CANCDMOB = 0;
    CANIDT4  = 0;
    CANIDT3  = 0;
    CANIDT2  = 0;
    CANIDT1  = 0;
    CANIDM4  = 0;
    CANIDM3  = 0;
    CANIDM2  = 0;
    CANIDM1  = 0;
    for (num_data = 0; num_data < NB_DATA_MAX; num_data++)
    {
      CANMSG = 0;
    }
  }
}

/*F****************************************************************************
* FUNCTION_NAME: Can_get_MOB_free                                                  
*----------------------------------------------------------------------------
* PARAMS:   none
* return:   handle of MOb 
*----------------------------------------------------------------------------
* PURPOSE: This function return the number of the first MOb available
* or 0xFF if no MOb available 
*****************************************************************************/
Uchar Can_get_MOB_free (void)
{
  Uchar num_MOB, Save_page;

  Save_page = CANPAGE;
  for (num_MOB = 0; num_MOB < NB_MOB; num_MOB++)
  {
    Can_set_MOB(num_MOB);
    if ((CANCDMOB&0xC0) == 0x00) // Disable configuration
    {
      CANPAGE = Save_page;
      return (num_MOB);
    }
  }
  CANPAGE = Save_page;
  return (NO_MOB);
}



/*F**************************************************************************
* NAME: Can_get_MOB_status 
*----------------------------------------------------------------------------
* PARAMS: none  
* return: mob_status : MOB_COMPLETED | MOB_NOT_COMPLETED | MOB_DISABLE  
*----------------------------------------------------------------------------
* PURPOSE: This function return information MOB completed its job 
* (MOB_COMPLETED) if one of the RXOK or TXOK Flag is set or MOB not completed 
* its job (MOB_NOT_COMPLETED) if no RXok and TXOK flags are set.
* Previously, this function check if the MOb is configured or not.
* In the case of the MOB is not configured, the function return MOB_DISABLE.
*----------------------------------------------------------------------------
* EXAMPLE:
*----------------------------------------------------------------------------
* NOTE: 
*----------------------------------------------------------------------------
* REQUIREMENTS: 
*****************************************************************************/
Uchar Can_get_MOB_status (void)
{ 
  /* test if mob is completed*/
  if (CANSTMOB&(1<<TXOK))     {return(MOB_TX_COMPLETED);}
  if (CANSTMOB&(1<<RXOK))     {return(MOB_RX_COMPLETED);}
  /* test if mob enabled */
  if ((CANCDMOB&0xC0) == 0x00){return(MOB_DISABLE);}
  return(MOB_NOT_COMPLETED);
}

/*F****************************************************************************
* FUNCTION_NAME: Can_get_data                                                  
*----------------------------------------------------------------------------
* PARAMS:   add
* return:   none
*----------------------------------------------------------------------------
* PURPOSE: This function copy the data from the selected MOb to the address
* passed in parameter.
* 
*****************************************************************************/
void Can_get_data (Uchar * pt_data)
{
  Uchar nb_data;
  
  for (nb_data = 0; nb_data <(CANCDMOB&DLC_msk); nb_data++)
  {
    *(pt_data + nb_data) = CANMSG;
  }
}

























