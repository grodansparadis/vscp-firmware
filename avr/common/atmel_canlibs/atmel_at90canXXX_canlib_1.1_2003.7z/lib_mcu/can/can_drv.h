/*H**************************************************************************
* $RCSfile: can_drv.h,v $
*----------------------------------------------------------------------------
* Copyright (c) 2003 Atmel.
*----------------------------------------------------------------------------
* RELEASE:      $Name:  $      
* REVISION:     $Revision: 1.1 $     
* FILE_CVSID:   $Id: can_drv.h,v 1.1 2005/12/21 11:29:17 akhe Exp $       
*----------------------------------------------------------------------------
* PURPOSE: 
* This file contains all prototypes and macros exported for FROYA. 
*****************************************************************************/

#ifndef _CAN_DRV_H_
#define _CAN_DRV_H_

/*_____ I N C L U D E - F I L E S ____________________________________________*/

/*_____ C O N S T A N T E S - D E F I N I T I O N  ___________________________*/

#define NB_MOB      15
#define NB_DATA_MAX 8
#define LAST_MOB_NB 14
#define NO_MOB 0xFF

/* constants returned by the function CAN_get_MOb_status */
#define MOB_TX_COMPLETED    0x00
#define MOB_RX_COMPLETED    0x01
#define MOB_NOT_COMPLETED   0x02
#define MOB_DISABLE         0xFF

/*_____ M A C R O S - DE C L A R A T I O N ___________________________________*/

#define Can_enable()    { CANGCON |= (1<<ENA); }

#ifndef CAN_BAUDRATE
 #error CAN_BAUDRATE must be defined in config.h
#elif CAN_BAUDRATE == CANAUTOBAUD
  #include "can_autobaud.h"
  #define Can_bit_timing ASM_CAN_AUTOBAUD()
#else
  #include "can_bdr.h"
  #define Can_bit_timing() {CANBT1=CONF_CANBT1;CANBT2=CONF_CANBT2;CANBT3=CONF_CANBT3;} 
#endif

#define Can_set_MOB(mob) (CANPAGE = (mob << 4))
#define Can_clear_MOB()  {CANSTMOB = 0x00; CANCDMOB = 0x00; CANIDM1=0x00; \
                          CANIDM2=0x00; CANIDM3=0x00; CANIDM4=0x00; CANIDT4 = 0x00;}

/*----- Identifier definition -----*/
#define CAN_SET_STD_ID_10_4(identifier) (((*((Uchar *)(&identifier)+1))<<5)+((*(Uchar *)(&identifier))>>3))
#define CAN_SET_STD_ID_3_0(identifier)  ((*(Uchar *)(&identifier))<<5)
#define Can_set_std_id(identifier) {\
        CANIDT1 = CAN_SET_STD_ID_10_4 (identifier);\
        CANIDT2 = CAN_SET_STD_ID_3_0  (identifier);}
#define Can_set_std_remote_id(identifier) {\
        CANIDT1 = CAN_SET_STD_ID_10_4 (identifier);\
        CANIDT2 = CAN_SET_STD_ID_3_0  (identifier);\
        CANIDT4 = (1<<RTRTAG);}

#define CAN_SET_EXT_ID_28_21(identifier) (((*((Uchar *)(&identifier)+3))<<3)+((*((Uchar *)(&identifier)+2))>>5))
#define CAN_SET_EXT_ID_20_13(identifier) (((*((Uchar *)(&identifier)+2))<<3)+((*((Uchar *)(&identifier)+1))>>5))
#define CAN_SET_EXT_ID_12_5(identifier)  (((*((Uchar *)(&identifier)+1))<<3)+((* (Uchar *)(&identifier)   )>>5))
#define CAN_SET_EXT_ID_4_0(identifier)    ((* (Uchar *)(&identifier)   )<<3)

#define Can_set_ext_id(identifier) {\
        CANIDT1 = CAN_SET_EXT_ID_28_21 (identifier);\
        CANIDT2 = CAN_SET_EXT_ID_20_13 (identifier);\
        CANIDT3 = CAN_SET_EXT_ID_12_5  (identifier);\
        CANIDT4 = CAN_SET_EXT_ID_4_0   (identifier);\
        CANCDMOB |= (1<<IDE); }

#define Can_set_ext_remote_id(identifier) {\
        CANIDT1 = CAN_SET_EXT_ID_28_21 (identifier);\
        CANIDT2 = CAN_SET_EXT_ID_20_13 (identifier);\
        CANIDT3 = CAN_SET_EXT_ID_12_5  (identifier);\
        CANIDT4 = CAN_SET_EXT_ID_4_0   (identifier);\
        CANCDMOB |= (1<<IDE); \
        CANIDT4 |= (1<<RTRTAG);}



#define Can_get_ext_id(identifier){     \
        *((Uchar *)(&identifier)+3) = CANIDT1>>3;   \
        *((Uchar *)(&identifier)+2) = (CANIDT2>>3)+(CANIDT1<<5);   \
        *((Uchar *)(&identifier)+1) = (CANIDT3>>3)+(CANIDT2<<5);   \
        *((Uchar *)(&identifier))   = (CANIDT4>>3)+(CANIDT3<<5);   \
}


#define Can_get_std_id(identifier){  \
        *((Uchar *)(&identifier)+1) = CANIDT1>>5; \
        *((Uchar *)(&identifier)  ) = (CANIDT2>>5)+(CANIDT1<<3); \
}


/*----- MOB configuration -----*/
#define Can_set_dlc(dlc) {CANCDMOB|=dlc;}

#define CH_TxENA   1
#define CH_RxENA   2
#define CH_RxBENA  3

#define DISABLE_CHANNEL        ( CANCDMOB &= (~CONMOB_msk) ) 
#define Can_config_tx()      { CANCDMOB |=  (CH_TxENA  << CONMOB); } 
#define Can_config_rx()      { DISABLE_CHANNEL ; CANCDMOB |=  (CH_RxENA  << CONMOB); } 
#define Can_config_rxbuffer() { DISABLE_CHANNEL ; CANCDMOB |=  (CH_RxBENA << CONMOB); } 

#define Can_MOB_abort()   {CANCDMOB &= (~CONMOB_msk);}
#define Can_get_dlc()     (CANCDMOB & DLC_msk)
#define Can_get_ide()     (CANCDMOB & (1<<IDE)) 
#define Can_get_rtr()     ((CANIDT4 & (1<<RTRTAG))>>RTRTAG)

/*_____ T Y P E D E F - D E C L A R A T I O N ________________________________*/

typedef enum {
  MOB_0, MOB_1, MOB_2, MOB_3, MOB_4, MOB_5, MOB_6, MOB_7, 
  MOB_8, MOB_9, MOB_10, MOB_11, MOB_12, MOB_13, MOB_14} can_mob_t; 


/*_____ P R O T O T Y P E S - D E C L A R A T I O N __________________________*/

extern void Can_clear_all_MOB (void);
extern Uchar Can_get_MOB_free (void);
extern Uchar Can_get_MOB_status (void);
extern void Can_get_data (Uchar *);

#endif /* _CAN_DRV_H_ */
