/**
 * @file $RCSfile: can_lib.c,v $
 *
 * Copyright (c) 2004 Atmel.
 *
 * Please read file license.txt for copyright notice.
 *
 * @brief This file contains CAN lib routines.
 *
 * @version $Revision: 1.1 $ $Name:  $
 *
 */

/*_____ I N C L U D E - F I L E S ____________________________________________*/
#include "config.h"
#include "lib_mcu/can/can_lib.h"

/*_____ G L O B A L S ________________________________________________________*/

#define STATUS_MOB_USED      0x01
#define STATUS_MOB_AVAILABLE 0x00

/*_____ P R I V A T E - F U N C T I O N S - D E C L A R A T I O N ____________*/

/*_____ L O C A L S __________________________________________________________*/

/*_____ P U B L I C - F U N C T I O N S ______________________________________*/

/*_____ P R I V A T E - F U N C T I O N S ____________________________________*/

void can_init (void)
{
  Can_bit_timing();
  Can_clear_all_MOB();
  Can_enable();  
 
}


Uchar can_cmd (st_cmd_t* cmd)
{
  Uchar mob_handle, cpt;
  
  if (cmd->cmd == CMD_ABORT)
  {
    if (cmd->status!= STATUS_MOB_AVAILABLE)
    {
      Can_set_MOB(cmd->handle);
      Can_MOB_abort();
      cmd->handle = 0;
      cmd->status = STATUS_MOB_AVAILABLE; 
    }
  }
  else
  {
    mob_handle = Can_get_MOB_free();
    cmd->status = STATUS_MOB_USED; 
 
    if (mob_handle!= NO_MOB)
    {
      cmd->handle = mob_handle;
      Can_set_MOB(mob_handle);
      Can_clear_MOB();    
      switch (cmd->cmd){
        case CMD_TX:    
          if (cmd->ctrl.ide){ Can_set_ext_id (cmd->id.ext);}
          else               { Can_set_std_id(cmd->id.std);}
          for (cpt=0;cpt<cmd->dlc;cpt++) CANMSG = *(cmd->pt_data + cpt);         
          Can_set_dlc(cmd->dlc);
          Can_config_tx();
          break;
      
        case CMD_TX_REMOTE:       
          if (cmd->ctrl.ide){ Can_set_ext_remote_id (cmd->id.ext);}
          else               { Can_set_std_remote_id(cmd->id.std);}
          Can_set_dlc(cmd->dlc);
          Can_config_tx();
          break;
           
        case CMD_RX:
          Can_config_rx();       
          break;
        
        default:
           cmd->status = STATUS_MOB_AVAILABLE; 
         break;
      }
    }else {return CAN_CMD_REFUSED;}
  }
  return CAN_CMD_ACCEPTED;
}


Uchar can_getstatus (st_cmd_t* cmd)
{
  Uchar status;
 
  if (cmd->status == STATUS_MOB_AVAILABLE) {return CAN_STATUS_DISABLED;}
  Can_set_MOB(cmd->handle);
  status = Can_get_MOB_status();
  if (status == MOB_RX_COMPLETED)
  {    
    cmd->status = 0;
    cmd->dlc = Can_get_dlc();
    Can_get_data(cmd->pt_data);
    cmd->ctrl.rtr = Can_get_rtr();

    if (Can_get_ide()) // if extended frame
    {
      cmd->ctrl.ide = 1; // extended frame
      Can_get_ext_id(cmd->id.ext);
    }
    else // else standard frame
    {
      cmd->ctrl.ide = 0;
      Can_get_std_id(cmd->id.std);
    }
    Can_MOB_abort(); // freed the MOB
    return CAN_STATUS_COMPLETED;

  }else if (status == MOB_TX_COMPLETED)
  {
    cmd->status = 0;
    Can_MOB_abort(); // freed the MOB
    return CAN_STATUS_COMPLETED;
  }
 
  return (status);
}

