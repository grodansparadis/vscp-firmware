/*H**************************************************************************
* $RCSfile: uart_bdr.h,v $         
*----------------------------------------------------------------------------
* Copyright (c) 2003 Atmel.
*----------------------------------------------------------------------------
* RELEASE:      $Name:  $      
* REVISION:     $Revision: 1.1 $     
* FILE_CVSID:   $Id: uart_bdr.h,v 1.1 2005/12/21 11:29:21 akhe Exp $       
*----------------------------------------------------------------------------
* PURPOSE: 
* Provide Baudrate configuration for MCU
*****************************************************************************/
#ifndef _UART_BDR_H
#define _UART_BDR_H

#define Uart_set_baudrate(bdr)  ( UBRRH = (Uchar)((((Uint32)FOSC*1000L)/((Uint32)bdr*16)-1)>>8),\
                                  UBRRL = (Uchar)(((Uint32)FOSC*1000 )/((Uint32)bdr*16)-1)    )

#endif/* _UART_BDR_H */

