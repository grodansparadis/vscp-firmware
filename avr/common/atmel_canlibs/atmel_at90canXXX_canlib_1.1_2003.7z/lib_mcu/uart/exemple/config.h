/*H**************************************************************************
* $RCSfile: config.h,v $         
*----------------------------------------------------------------------------
* Copyright (c) 2003 Atmel.
*----------------------------------------------------------------------------
* RELEASE:      $Name:  $      
* REVISION:     $Revision: 1.1 $     
* FILE_CVSID:   $Id: config.h,v 1.1 2005/12/21 11:29:21 akhe Exp $       
*----------------------------------------------------------------------------
* PURPOSE: 
* Configuration file. Selection of the device.
*****************************************************************************/
#ifndef _CONFIG_H_
#define _CONFIG_H_


#define AVR
#define USE_UART1

/*_____ I N C L U D E S ____________________________________________________*/

#include "lib_mcu/compiler.h"
#include "lib_mcu/mcu.h"

/*_____ M A C R O S ________________________________________________________*/


/*_____ D E F I N I T I O N ________________________________________________*/

#define FOSC                    8000        // Available value: 22118 16000 12000 11059 custom

/*-------------- UART LIB CONFIGURATION ---------------*/
#define BAUDRATE    9600       
#define putchar uart_putchar


/*_____ D E C L A R A T I O N S ____________________________________________*/

#endif  /* CONFIG_H */


