/**
 * @file $RCSfile: flash_drv.h,v $
 *
 * Copyright (c) 2004 Atmel.
 *
 * Please read file license.txt for copyright notice.
 *
 * @brief This file contains a set of low level routines to perform flash access.
 *
 * @version $Revision: 1.1 $ $Name:  $
 *
 */
 
#ifndef FLASH_DRV_H
#define FLASH_DRV_H

/*_____ I N C L U D E S ____________________________________________________*/

#include "config.h"

/*_____ M A C R O S ________________________________________________________*/
#define Enable_flash()
#define Disable_flash()

#define Flash_RWW_Read_enable()   (flash_prg_page(0x00,(1<<RWWSRE)+(1<<SPMEN)))

#define Flash_page_erase(address) (flash_prg_page(address,(1<<PGERS) + (1<<SPMEN)))              

#define Flash_page_write(address)  (flash_prg_page(address,(1<<PGWRT) + (1<<SPMEN)),Flash_RWW_Read_enable())

/*_____ D E C L A R A T I O N S ____________________________________________*/

void flash_prg_page (unsigned long adr, unsigned char function);
void lock_wr_bits (unsigned char val);
void flash_fill_temp_buffer (unsigned int data,unsigned int adr);

#endif  /* FLASH_DRV_H */



