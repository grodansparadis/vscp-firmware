/*H**************************************************************************
* $RCSfile: spi_drv.h,v $
*----------------------------------------------------------------------------
* Copyright (c) 2003 Atmel.
*----------------------------------------------------------------------------
* RELEASE:      $Name:  $      
* REVISION:     $Revision: 1.1 $     
* FILE_CVSID:   $Id: spi_drv.h,v 1.1 2005/12/21 11:29:20 akhe Exp $       
*----------------------------------------------------------------------------
* PURPOSE: 
* . 
*****************************************************************************/

#ifndef _SPI_DRV_H_
#define _SPI_DRV_H_

/*_____ C O N S T A N T E S - D E F I N I T I O N  ___________________________*/

#define MSK_SPI_ENABLE_IT	   0x80
#define MSK_SPI_ENABLE		   0x40
#define MSK_SPI_MASTER_MODE	 0x10
#define MSK_SPI_DOUBLESPEED	 0x01

#define MSK_SPI_DIV4        0x00
#define MSK_SPI_DIV16       0x01
#define MSK_SPI_DIV64       0x02
#define MSK_SPI_DIV128      0x03
#define MSK_SPI_CPHA_LEADING  0x00
#define MSK_SPI_CPHA_TRAILING 0x04
#define MSK_SPI_CPOL_HIGH   0x08
#define MSK_SPI_CPOL_LOW    0x00
#define MSK_SPI_LSBFIRST    0x20
#define MSK_SPI_MSBFIRST    0x00
#define MSK_SPI_CONF  0x2F


/*_____ M A C R O S - DE C L A R A T I O N ___________________________________*/

#define Spi_enable_it()         (SPCR|= MSK_SPI_ENABLE_IT)
#define Spi_disable_it()        (SPCR&=~MSK_SPI_ENABLE_IT)
#define Spi_enable()            (SPCR|= MSK_SPI_ENABLE)
#define Spi_disable()           (SPCR&=~MSK_SPI_DISABLE)
#define Spi_select_slave_mode() (SPCR&=~MSK_SPI_MASTER_MODE)
#define Spi_select_master_mode() (SPCR|= MSK_SPI_MASTER_MODE)
#define Spi_hw_init(conf)       (SPCR&=~MSK_SPI_CONF, SPCR|=conf)
#define Spi_get_colision_status() (SPSR&(1<<WCOL))
#define Spi_get_byte()          (SPDR)
#define Spi_send_byte(ch)       (SPDR=ch)
#define Spi_tx_ready()          (SPSR & (1<<SPIF))
#define Spi_rx_ready()		      Spi_tx_ready()
#define Spi_set_doublespeed()   (SPSR|= MSK_SPI_DOUBLESPEED)


#endif /* _SPI_DRV_H_ */
