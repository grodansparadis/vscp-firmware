/*H**************************************************************************
* $RCSfile: config.h,v $         
*----------------------------------------------------------------------------
* Copyright (c) 2003 Atmel.
*----------------------------------------------------------------------------
* RELEASE:      $Name:  $      
* REVISION:     $Revision: 1.1 $     
* FILE_CVSID:   $Id: config.h,v 1.1 2005/12/21 11:29:20 akhe Exp $       
*----------------------------------------------------------------------------
* PURPOSE: 
* Configuration file. Selection of the device.
*****************************************************************************/
#ifndef _CONFIG_H_
#define _CONFIG_H_



/*_____ I N C L U D E S ____________________________________________________*/

#include "lib_mcu/compiler.h"
#include "lib_mcu/mcu.h"


/*_____ M A C R O S ________________________________________________________*/


/*_____ D E F I N I T I O N ________________________________________________*/

#define FOSC                    8000        

/*-------------- SPI LIB CONFIGURATION ---------------*/
#define SPI_CONFIG  (MSK_SPI_DIV4 | MSK_SPI_LSBFIRST | MSK_SPI_CPHA_LEADING |MSK_SPI_CPOL_LOW)


/*_____ D E C L A R A T I O N S ____________________________________________*/

#endif  /* CONFIG_H */


