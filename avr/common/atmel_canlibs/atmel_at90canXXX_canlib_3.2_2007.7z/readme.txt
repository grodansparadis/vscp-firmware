The can lib itself is in lib_mcu.

lib_board and lib_module are support files for the DVK90CAN1 development
board from atmel.

This folder was taken from the original Release archive, which can be found
here:

http://www.atmel.com/dyn/products/product_card.asp?part_id=3795
http://www.atmel.com/dyn/resources/prod_documents/at90CANLIB_3_2.zip
