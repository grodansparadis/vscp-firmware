void initbootuart();
void sendchar( char );
char recchar( void );
