The two files ReadRC5.asm and ReadRC5.pdf describe a device to read
incoming IR remote control codes of the Philips RC5 and Extended RC5
format, and display them on a 2 line x 20 character LCD.

The two Microsoft Excel files RC5pict.xls and RC5mpict.xls illustrate
the timing specifications for the two formats.

Philips RC5 IR signals use a 36 kHz carrier frequency, so best results
will be obtained when the pickup module is tuned to 36 kHz.  Sharp 
part number GP1U580X was used in the prototype.  Temic part number
TFMS5360 also works well.

This information is released into the public domain for personal use only.
