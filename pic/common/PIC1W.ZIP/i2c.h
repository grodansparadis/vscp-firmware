/*********************************************************************
 *
 *               I2C Definitions
 *
 *********************************************************************
 */
#ifndef I2C_H
#define I2C_H

#include "projdefs.h"

// Port configuration details
#define   MASTER    8     /* I2C Master mode                    */
/* SSPSTAT REGISTER */
#define   SLEW_OFF  0xC0  /* Slew rate disabled for 100kHz mode */
#define   SLEW_ON   0x00  /* Slew rate enabled for 400kHz mode  */
#define   SSPENB    0x20  /* Enable serial port and configures
                             SCK, SDO, SDI                      */
#define I2C_BAUD(CLOCK, BAUD)      ( ((CLOCK / BAUD) / 4) - 1 )

typedef enum _I2C_RESULT
{
    I2C_SUCCESS = 0,
    I2C_READY = 0,
    I2C_BUS_COLLISION,
    I2C_WCOL_COLLISION,
    I2C_NAK,
    I2C_VERIFY_ERR,
    I2C_BUSY
} I2C_RESULT;


// function prototypes and macros
#define StartI2C()      SSPCON2_SEN=1
#define RestartI2C()    SSPCON2_RSEN=1
#define StopI2C()       SSPCON2_PEN=1
#define IdleI2C()       while ( ( SSPCON2 & 0x1F ) | ( SSPSTAT_R_W ) );
#define NotAckI2C()     SSPCON2_ACKDT=1, SSPCON2_ACKEN=1
void InitI2C(unsigned char baud);
unsigned char ReadI2C( void );
I2C_RESULT WriteI2C( unsigned char );
I2C_RESULT SessionBeginI2C(unsigned char);
I2C_RESULT SessionReStartI2C(unsigned char);
unsigned char ReadByteI2C(void);
unsigned char ReadLastI2C(void);
I2C_RESULT WriteByteI2C(unsigned char);
I2C_RESULT SessionEndI2C(void);

#endif
