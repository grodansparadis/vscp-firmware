// i2c.c
//               I2C Routines
//
// Very low level routines (typically 1 bit or 1 byte)
// StartI2C		MACRO	Issue a START pulse
// RestartI2C	MACRO	Issue a RESTART pulse
// StopI2C		MACRO	Issue a STOP pulse
// IdleI2C		MACRO	Wait for IDLE condition
// NotAckI2C	MACRO	Issue a NAK pulse
// InitI2C				Peripheral setup
// ReadI2C				Read one character from I2C port
// WriteI2C				Write one character to I2C port
//
// Low level routines
// SessionBeginI2C		Start and Send I2C slave address
// SessionRestartI2C	Restart I2C session
// ReadByteI2C			Read a byte from slave and send an ACK
// ReadLastI2C			Read a byte from slave and send a NAK
// WriteByteI2C			Write a byte to slave and confirm ACK
// SessionEndI2C		Finish session

#include "i2c.h"

/* InitI2C
 */
void InitI2C(unsigned char baud) {
  SSPSTAT &= 0x3F;              // power on state
  SSPCON1 = 0x00;               // power on state
  SSPCON2 = 0x00;               // power on state
  SSPCON1 |= MASTER;            // select serial mode
//  SSPSTAT |= SLEW_ON;			// slew rate on/off
  SSPSTAT |= SLEW_OFF;			// slew rate on/off
  TRISC_RC3 = 1;                // Set SCL (PORTC,3) pin to input
  TRISC_RC4 = 1;                // Set SDA (PORTC,4) pin to input. Is controlled by I2C hardware
  SSPCON1 |= SSPENB;            // enable synchronous serial port
  SSPADD = baud;
}

/********************************************************************
*     Function Name:    WriteI2C                                    *
*     Return Value:     Status byte for WCOL detection.             *
*     Parameters:       Single data byte for I2C bus.               *
*     Description:      writes a single byte to the I2C bus.        *
********************************************************************/
I2C_RESULT WriteI2C( unsigned char data_out ) {
  SSPBUF = data_out;			// write single byte to SSPBUF
  if ( SSPCON1_WCOL )			// test if write collision occurred
   return (I2C_WCOL_COLLISION);
  else
  {
    while( SSPSTAT_BF )
    	;						// wait until write cycle is complete
    return (I2C_SUCCESS);
  }
}

/********************************************************************
*     Function Name:    ReadI2C                                     *
*     Return Value:     contents of SSPBUF register                 *
*     Parameters:       void                                        *
*     Description:      Read single byte from I2C bus.              *
********************************************************************/
unsigned char ReadI2C( void ) {
  SSPCON2_RCEN = 1;					// enable master for 1 byte reception
  while ( !SSPSTAT_BF )
  	;								// wait until byte received
  return ( SSPBUF );				// return with read byte
}

// SessionBeginI2C			Start and Send I2C slave address
I2C_RESULT SessionBeginI2C(unsigned char ia) {
    IdleI2C();							// ensure module is idle
    StartI2C();							// initiate START condition
    while ( SSPCON2_SEN )
    	;								// wait until start condition is over
    if ( PIR2_BCLIF )					// test for bus collision
        return I2C_BUS_COLLISION;		// return with Bus Collision error        
    if ( WriteI2C(ia) != I2C_SUCCESS )	// write 1 byte
        return I2C_WCOL_COLLISION;		// set error for write collision
    IdleI2C();							// ensure module is idle
    if ( SSPCON2_ACKSTAT )				// test for ACK condition, if received
		return I2C_NAK;					// return with Not Ack error
    return I2C_SUCCESS;
}

// SessionReStartI2C			Restart Session
I2C_RESULT SessionReStartI2C(unsigned char ia) {
    IdleI2C();							// ensure module is idle
    RestartI2C();						// initiate RESTART condition
    while ( SSPCON2_SEN )
    	;								// wait until start condition is over
    if ( PIR2_BCLIF )					// test for bus collision
        return I2C_BUS_COLLISION;		// return with Bus Collision error
    IdleI2C();
    if ( WriteI2C(ia) != I2C_SUCCESS )	// write 1 byte  ** TODO Why does this fail?
        return I2C_WCOL_COLLISION;		// set error for write collision
    IdleI2C();							// ensure module is idle
    if ( SSPCON2_ACKSTAT )				// test for ACK condition, if received
		return I2C_NAK;					// return with Not Ack error
    return I2C_SUCCESS;
}

// ReadByteI2C			Read a byte from slave and send an ACK
unsigned char ReadByteI2C(void) {
    ReadI2C();
    while( SSPCON2_RCEN )
    	;					// wait for receive sequence
    SSPCON2_ACKDT = 0;      // Set ack bit
    SSPCON2_ACKEN = 1;
    while( SSPCON2_ACKEN )
    	;					// wait for ACK to finish
    return SSPBUF;
}

// ReadLastI2C			Read a byte from slave and send a NAK
unsigned char ReadLastI2C(void) {
    ReadI2C();
    while( SSPCON2_RCEN )
    	;  						// wait for receive sequence
    NotAckI2C();
    while( SSPCON2_ACKEN )
    	;						// wait for NAK to finish
	return SSPBUF;
}

// WriteByteI2C			Write a byte to slave and confirm ACK
I2C_RESULT WriteByteI2C(unsigned char c) {
	IdleI2C();
    if ( WriteI2C(c) )
        return I2C_BUS_COLLISION;
	IdleI2C();
    if ( SSPCON2_ACKSTAT )
        return I2C_NAK;
    return I2C_SUCCESS;
}

// SessionEndI2C			Finish session
I2C_RESULT SessionEndI2C(void) {
    IdleI2C();
    StopI2C();				// Send STOP pulse
    while(SSPCON2_PEN)
    	;					// Wait for end of STOP
// ** TODO - Is this necessary? Originally used by XEEClose and XEEIsBusy
    if ( PIR2_BCLIF )		// Test for collision
        return I2C_BUS_COLLISION;
    return I2C_SUCCESS;
}
