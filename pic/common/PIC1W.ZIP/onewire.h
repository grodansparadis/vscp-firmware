/*
 *	OneWire handler
 *
 */


#ifndef _ONEWIRE_H_
#define _ONEWIRE_H_

#include "projdefs.h"

// Strings
static ROM char strOneWireSearch[] = "OneWire - Searching ";
static ROM char strOneWireDeviceFound[] = "OneWire - Device found";

/////////////////////////////////////////////////
//Global defines


/////////////////////////////////////////////////
//Global data
/*
extern BYTE rtcSecond;	   //second, minute, hour, day, month, year
*/
/////////////////////////////////////////////////
//Function prototypes

//void SchedExec(void);

// OneWire I2C Function Codes
#define W1FC_DRST	0xF0
#define W1FC_WCFG	0xD2
#define W1FC_SRP	0xE1
#define W1FC_1WRS	0xB4
#define W1FC_1WWB	0xA5
#define W1FC_1WRB	0x96
#define W1FC_1WSB	0x87
#define W1FC_1WT	0x78

// DS2482 Register addresses
#define DSRA_SR		0xF0
#define DSRA_RDR	0xE1
#define DSRA_CR		0xC3

// DS2482 I2C Address
#define DS2482		0x30

// OneWire Global Commands
enum OWGlobal {ReadROM = 0x33, MatchROM = 0x55, SkipROM = 0xCC, SearchROM = 0xF0};
// OneWire Family codes
enum OWFamilyCode {
	DS1990A = 0x01, DS1991  = 0x02, DS2404  = 0x04, DS2405  = 0x05,
	DS1993  = 0x06, DS1992  = 0x08, DS1982  = 0x09, DS1995  = 0x0A,
	DS1985  = 0x0B, DS1996  = 0x0C, DS1986  = 0x0F, DS1XS20 = 0x10,
	DS2406  = 0x12, DS1983  = 0x13, DS2430A = 0x14, DS1954  = 0x16,
	DS19631 = 0x1A, DS2423  = 0x1D, DS2409  = 0x1F,
	DS2450  = 0x20, DS1921  = 0x21, DS1822  = 0x22, DS2433  = 0x23,
	DS2415  = 0x24, DS2438  = 0x26, DS2417  = 0x27, DS18B20 = 0x28,
	DS2890  = 0x2C, DS2760  = 0x30, DS2432  = 0x33, DS2422  = 0x41};

enum OWDS1820Cmd {StartConv = 0x44, WriteScratchpad = 0x4E, CopyScratchpad=0x48, ReadScratchpad = 0xBE, RecallEE = 0xB8, ReadPwrSup = 0xB4};

enum OWStatus {WB = 1, PPD = 2, SD = 4, LL = 8, RST = 0x10, SBR = 0x20, TBP = 0x40, DIR = 0x80};

/*

  t_Authorization = Record
                     TA1 :Byte;
                     TA2 :Byte;
                     ES: Byte;
                     end;

  t_OW_Serial    =  Record
                      CRC            : Byte;
                      Serial         : Array[0..5] of Byte;
                      FamilyCode     : t_familyCode;
                    end;
*/

// function prototypes
void OneWireInit(void);
void OneWireReadTemp(void);
void OneWireReadScratch(short);

#endif	//_CLOCK_H_
