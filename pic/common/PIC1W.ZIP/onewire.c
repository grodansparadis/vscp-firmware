/*
 * OneWire handler
 *
 */

// Low level routines
// OneWireWFC					Write Function Code with zero parameters
// OneWireWFC1P					Write Function Code with one parameter
// OneWireRFC					Read Function Code with one byte expected

// Medium level routines
// OneWireInit					Initialize the DS2482
// OneWireSetReadPtr			Set the Read Pointer
// OneWireWriteConfig			Write a configuration byte
// OneWireReset					Resets the OneWire bus
// OneWireWriteByte				Write one byte to the OneWire bus
// OneWireReadByte				Read one byte from the OneWire bus
// OneWireTriplet				Special function for bus search

// High level routines

// OneWireNotBusy				Wait for 1W activity to finish
// OneWireReset					Send a reset pulse
// OneWireInit					Initialize the interface
// OneWireReadBus				Read a byte from the 1W bus
// OneWireWriteBus				Write a byte to the 1W bus

#define THIS_IS_ONEWIRE

#include "onewire.h"
#include "serint.h"
#include "i2c.h"
#include "thermostat.h"
#include "stdlib.h"
#include "stdio.h"

extern unsigned char Tsn[TINMAX][8];
extern float Tin[TINMAX];

// I2C Level routines (to/from DS2482)
I2C_RESULT OneWireWFC(unsigned char ia, unsigned char fc) {
	I2C_RESULT r;

	r = SessionBeginI2C(ia);					// Start I2C session, send I2C slave address
	if (r == I2C_SUCCESS) {
		r = WriteByteI2C(fc);					// Send the Function Code to the I2C bus
	}
	SessionEndI2C();							// End the I2C session
	return(r);
}

I2C_RESULT OneWireWFC1P(unsigned char ia, unsigned char fc, unsigned char p1) {
	I2C_RESULT r;

	r = SessionBeginI2C(ia);					// Start I2C session, send I2C slave address
	if (r == I2C_SUCCESS) {
		r = WriteByteI2C(fc);					// Send the Function Code to the I2C bus
		r = WriteByteI2C(p1);					// Send the parameter to the I2C bus
	}
	SessionEndI2C();							// End the I2C session
	return(r);
}

// Read one character from whatever the Read Pointer is set to
I2C_RESULT OneWireRead(unsigned char ia, unsigned char* rc) {
	I2C_RESULT r;

	r = SessionBeginI2C(ia + 1);
	if (r == I2C_SUCCESS) {				// Start I2C session, send I2C slave address
		*rc = ReadLastI2C();			// Get the character
	}
	SessionEndI2C();					// End the I2C session
	return r;
}

// Bus level routines (to/from 1W bus)

// Wait for the WB line to go down
void OneWireNotBusy(void) {
	unsigned char c;

	OneWireWFC1P(DS2482, W1FC_SRP, DSRA_SR);
	do { OneWireRead(DS2482, &c); }		// Get Status Register
	while (c & WB);
}

// Write one byte to the 1W bus
I2C_RESULT OneWireWriteBus(unsigned char tc) {
	I2C_RESULT r;

	r = OneWireWFC1P(DS2482, W1FC_1WWB, tc);	// 1W bus write
	if (r == I2C_SUCCESS) {
		OneWireNotBusy();						// Wait for 1W bus to finish
	}
	return(r);
}

// Read one byte from the 1W bus
I2C_RESULT OneWireReadBus(unsigned char* rc) {
	I2C_RESULT r;

	r = OneWireWFC(DS2482, W1FC_1WRB);			// 1W bus read
	if (r == I2C_SUCCESS) {
		OneWireNotBusy();						// Wait for 1W bus to finish
		r = OneWireWFC1P(DS2482, W1FC_SRP, DSRA_RDR);
		if (r == I2C_SUCCESS) {
			r = OneWireRead(DS2482, rc);		// Get char from I2C
		}
	}
	return(r);
}

// Reset the 1W bus
I2C_RESULT OneWireReset(void) {	
	I2C_RESULT r;

	r = OneWireWFC(DS2482, W1FC_1WRS);			// Sets Read Pointer to Status Register
	if (r == I2C_SUCCESS) {
		OneWireNotBusy();
	}
	return(r);
}

// static variables
static short n;
static unsigned char scratch[10];
static unsigned char sn[8] = { 0x28, 0x5B, 0xD2, 0x1B, 0x00, 0x00, 0x00, 0xB9 };

// Initialize the DS2482
void OneWireInit(void) {
	I2C_RESULT r;
	
	// Init DS2482 OneWire interface
	r = OneWireWFC(DS2482, W1FC_DRST);
	printf((rom char*) "1W Init %02hhd", r);
	PutReturn();
/*
	// Show the sn of the device (only works if there is just one device)
	OneWireReset();
	OneWireWriteBus(ReadROM);	
	for (n = 0; n < 8; n++) {
		OneWireReadBus(&scratch[n]);
	}
	for (n = 0; n < 8; n++) {
	}
	printf((rom char*) "SN = %02X-%02X-%02X-%02X-%02X-%02X-%02X-%02X\r\n", 
		scratch[0], scratch[1], scratch[2], scratch[3],
		scratch[4], scratch[5], scratch[6], scratch[7]);
*/
}

// Start Temperature conversions on ALL devices
void OneWireReadTemp(void) {
	I2C_RESULT r;
	
	// Start DS18x20 temperature conversions in ALL devices
	r = OneWireReset();
	if (r == I2C_SUCCESS) {
		OneWireWriteBus(SkipROM);							// ALL devices
		OneWireWFC1P(DS2482, W1FC_WCFG, 0b10110100);		// Strong pullup next
		OneWireWriteBus(StartConv);							// Start Conversion
	}
}

// Read Scratchpad memory from the device specified in sn
void OneWireReadScratch(short Nsc) {
	float x;

	OneWireReset();								// End Strong pullup
	OneWireWriteBus(MatchROM);					// Tell devices to watch for ID
	for (n = 0; n < 8; n++) {
		OneWireWriteBus(Tsn[Nsc][n]);			// ID of the device we want
	}
	OneWireWriteBus(ReadScratchpad);			// Read Result
	for (n = 0; n < 9; n++) {
		OneWireReadBus(&scratch[n]);
	}

// ** check for no data condition TH = FF, TL = FF
// ** check for reset condition TH = 05, TL = 50

	printf((rom char*) "Nsc = %d, TH = %02X, TL = %02X", Nsc, scratch[1], scratch[0]);
	PutReturn();
	if ((scratch[1] & 0xF8) == 0)
		x = ((float)(scratch[1]*256) + (float)scratch[0])/16;				// result is positive
	else
		x = ((float)(scratch[1]&0x03*256) + (float)scratch[0])/16 - 64;		// result is negative
// if no errors, set output
	Tin[Nsc] = x;
}

void OneWireWriteScratch(void) {
	OneWireReset();									// End Strong pullup
	OneWireWriteBus(MatchROM);
	for (n = 0; n < 8; n++) {
		OneWireWriteBus(sn[n]);
	}
	OneWireWriteBus(WriteScratchpad);
	for (n = 0; n < 9; n++) {
		OneWireWriteBus(scratch[n]);
	}
}
