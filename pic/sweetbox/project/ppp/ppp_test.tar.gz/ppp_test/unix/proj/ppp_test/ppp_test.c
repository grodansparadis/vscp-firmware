/*
  GPRS example using lwIP 1.3
  Can not connect :(

date:  4. 13. 2008.
*/

#include <stdio.h>
#include <string.h>
#include <lwip/tcpip.h>
#include <lwip/stats.h>
#include <lwip/memp.h>
#include <lwip/tcp.h>
#include <lwip/udp.h>
#include <netif/ppp/ppp.h>

volatile int tcpdone=0, pppdone=0, tcp1_conn=0;
volatile int pd;
unsigned char debug_flags;

struct udp_pcb* udp1;
struct tcp_pcb *tcp1;


/** PPP callback */
void pppCallback(void *ctx, int errCode, void *arg)
{
  printf("> ppp init done, errcode= %d\n", errCode);
  if(errCode < 0){
    printf("> exit.\n");
    exit(EXIT_FAILURE);
  }
  pppdone=1;
}


void tcpipInitDone(void* param)
{
  printf("> tcp init done\n");
  tcpdone=1;
}


/** start PPP connection */
void doPPP()
{
  sio_fd_t *io;
  pppInit();

  io=sio_open(0);
  if (io==NULL){
    perror("> sio_open failed\n");
    exit(EXIT_FAILURE);
  }

  sio_send_string("AT+CGDCONT=1,\"IP\",\"internet\"\r\n", io);
  sio_flush(io);
  sio_expect_string("OK\r\n", io);

  sio_send_string("ATD*99***1#\r\n", io);
  sio_flush(io);
  sio_expect_string("CONNECT 115200\r\n", io); /* CONNECT baudrate\r\n  */

  pppSetAuth(PPPAUTHTYPE_NONE, "", ""); /* no authentication needed for my gprs subscription */

  pd=pppOpen(io, pppCallback, NULL);
}


err_t tcp_connected(void *arg, struct tcp_pcb *tpcb, err_t err)
{
  printf("> tcp_connected\n");
  tcp1_conn=1;
  return err;
}


err_t tcp_received(void *arg, struct tcp_pcb *tcpb, struct pbuf *p, err_t err)
{
  char buf[10000];
  struct pbuf* packet;
  char* data;

  memcpy(buf, p->payload, p->len);
  buf[p->len]=0;
  printf("> received packet from tcp channel: '%s'\n", buf);
  fflush(stdout);

  packet=pbuf_alloc(PBUF_TRANSPORT, 100, PBUF_RAM);
  data=(char*)packet->payload;
  snprintf(data, 100, "hi! you sent=<%s>\n", buf);
  if (udp_send(udp1, packet)!=ERR_OK) 
    perror("> send\n");
  return err;
}


void udp_received(void *arg, struct udp_pcb *upcb, struct pbuf *p, struct ip_addr *addr, u16_t port)
{
  char buf[10000];
  struct pbuf* packet;
  char * data;

  memcpy(buf, p->payload, p->len);
  buf[p->len]=0;
  printf("received packet from port %u, IP %0X: '%s'\n", port, addr->addr, buf);
  fflush(stdout);

  packet=pbuf_alloc(PBUF_TRANSPORT, 100, PBUF_RAM);
  data=(char*)packet->payload;
  snprintf(data, 100, "hi! you sent=<%s>\n", buf);
  if (udp_send(udp1, packet)!=ERR_OK) 
    perror("> send\n");
}


int main(int argc, char *argv[])
{
  struct ip_addr addr;
  unsigned short remote_port;
  struct pbuf* packet;
  char buf[1000];
  int err_code;

  /* debug everything */
  debug_flags = (LWIP_DBG_ON|LWIP_DBG_TRACE|LWIP_DBG_STATE|LWIP_DBG_FRESH|LWIP_DBG_HALT);

  sys_init();

  stats_init();

  mem_init();
  memp_init();
  pbuf_init();

  netif_init();
  tcpip_init(tcpipInitDone, NULL);
  while(!tcpdone);

  doPPP();

  printf("> waiting for ppp... \n");
  while(!pppdone);
  printf("> ppp done \n");      /* in my tests this program has never reached this point */


  printf("> press enter to send udp packet!\n");
  fread(buf, 1, 1, stdin);
  printf("> Sending udp  packet...\n");


  IP4_ADDR(&addr, 91,83,10,198); /* my IP address */
  remote_port=5400;              /* and an open port*/

  /* open UDP connenction and send test packet */

  udp1=udp_new();
  if (udp_connect(udp1, &addr, remote_port)!=ERR_OK)
    perror("> udp connect failed!\n");

  udp_recv(udp1, udp_received, NULL);

  if((err_code = udp_sendto(udp1, packet, &addr, remote_port))!=ERR_OK){
    perror("> udp send failed! \n");
    printf("> error code: %d\n", err_code);
  }
  else
    printf("> udp sent packet\n");


/* open TCP connenction and send test packet */

  tcp1 = tcp_new();
  if (tcp_connect(tcp1, &addr, remote_port, tcp_connected)!=ERR_OK)
    perror("> tcp connect failed!\n");

  tcp_recv(tcp1, tcp_received);

  printf("> waitong for tcp connect... \n");
  while(!tcp1_conn);
  printf("> tcp connected... \n");

  if((err_code = tcp_write(tcp1, "hi! :)\n", 7, TCP_WRITE_FLAG_COPY)) != ERR_OK){
    perror("> tcp send failed!! \n");
    printf("> error code: %d\n", err_code);
  }
  else
    printf("> tcp sent packet\n");

  printf("> press enter to exit!\n");
  fread(buf, 1, 1, stdin);

  tcp_close(tcp1);
  pppClose(pd);

  return EXIT_SUCCESS;
}
